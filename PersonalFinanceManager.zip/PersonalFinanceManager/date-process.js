const Sequelize = require('sequelize')
const Op = Sequelize.Op

module.exports = {
  getDateCriteria: selectedMonth => {
    if (!selectedMonth) { return {} }

    // Get next month
    let nextMonth = new Date(selectedMonth)
    nextMonth.setMonth(nextMonth.getMonth() + 1)
    return { [Op.between]: [new Date(selectedMonth), nextMonth] }
  },
  getFormattedMonth: record => {
    const date = new Date(record.date)
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    return `${year}/${month}`
  },
  getChartData: records => {
    const categories = { 
      'Housing': 0, 
      'Transportation': 0, 
      'Entertainment': 0, 
      'Food & Dining': 0, 
      'Other': 0 
    }
    records.forEach(record => { categories[record.category] += record.amount })
    return Object.values(categories)
  }
}
