// Include modules
const passport = require('passport')
const { validationResult } = require('express-validator')
const bcrypt = require('bcryptjs')
const Sequelize = require('sequelize')
const Op = Sequelize.Op
// Node.js built-in crypto to help create a unique random value for the token
const crypto = require('crypto')
const nodemailer = require('nodemailer')
const sendgridTransport = require('nodemailer-sendgrid-transport')

// Include models
const db = require('../models')
const User = db.User

// Set up transporter to tell nodemailer how the email will be delivered
const transporter = nodemailer.createTransport(sendgridTransport({
  auth: {
    // Hide secret key
    api_key: process.env.SENDGRID_KEY
  }
}))

module.exports = {
  getRegister: (req, res) => {
    res.render('register', {
      formCSS: true,
      formValidateJS: true
    })
  },
  postRegister: async (req, res) => {
    // Get user input
    const { name, email, password, rePassword } = req.body
    // Get all validation error messages in an object
    const errors = validationResult(req)
    // If any error messages are prompted, show a warning message
    if (!errors.isEmpty()) {
      return res.status(422).render('register', {
        formCSS: true,
        formValidateJS: true,
        errorMessages: errors.array(),
        user: { name, email, password, rePassword }
      })
    }

    try {
      // Check if this is an existing email, after passing validation
      const user = await User.findOne({ where: { email: email } })
      // If email already exists
      if (user) {
        req.flash('reminder', 'Account already registered, please log in directly')
        return res.redirect('/users/login')
      }

      // If new user email
      const salt = await bcrypt.genSalt(10)
      const hash = await bcrypt.hash(password, salt)

      // Store user into database
      await User.create({
        name: name,
        email: email,
        password: hash
      })

      // Redirect back to the login page after successful signup
      res.redirect('/users/login')
      // Check if it is currently in deploy mode 
      const link = "http://localhost:3000/"
      // Send successful signup email
      await transporter.sendMail({
        to: email,
        from: 'expense-tracker@example.com',
        subject: 'Registration Successful',
        html: `
          <p>${name}, you have successfully registered</p>
          <a href=${link}>Click here to access the Family Expense Tracker</a>
        `
      })
    } catch (err) {
      res.redirect('/users/register')
      console.log(err)
    }
  },
  getLogin: (req, res) => {
    res.render('login', {
      formCSS: true,
      formValidateJS: true
    })
  },
  getLogout: (req, res) => {
    // Remove req.user property and clear login session
    req.logout()
    // Show logout success message
    req.flash('success', 'You have successfully logged out')
    // Redirect back to the login page
    res.redirect('/users/login')
  },
  getReset: (req, res) => {
    res.render('reset', {
      formCSS: true,
      formValidateJS: true,
    })
  },
  postRest: async (req, res) => {
    try {
      // Generate random token
      const buffer = await crypto.randomBytes(32)
      const token = buffer.toString('hex')

      // Store token for the user planning to reset
      const user = await User.findOne({ where: { email: req.body.email } })

      // If no user is found
      if (!user) {
        req.flash('error', 'This Email is not registered')
        return res.redirect('/users/reset')
      }

      // User is found, add token
      user.resetToken = token
      // Token expires in an hour
      user.resetTokenExpiration = Date.now() + 3600000
      // Save token and expiration time
      await user.save()
      // Redirect back to login page
      res.redirect('/users/login')
      // Check if it is currently in deploy mode 
      const link = process.env.PORT ? `https://boiling-beach-19178.herokuapp.com/users/reset/${token}` : `http://localhost:3000/users/reset/${token}`
      // Send a reset email to the user with a unique token as a parameter
      transporter.sendMail({
        to: req.body.email,
        from: 'expense-tracker@example.com',
        subject: 'Reset Password',
        html: `
          <p>Hello ${user.name},</p>
          <p>Click <a href=${link}>this link</a> to reset your password</p>
        `
      })
    } catch (err) {
      res.redirect('/users/reset')
      console.log(err)
    }
  },
  getNewPassword: async (req, res) => {
    // Get the token embedded in the URL
    const token = req.params.token

    try {
      // Find the user in the database
      const user = await User.findOne({ where: { resetToken: token, resetTokenExpiration: { [Op.gt]: Date.now() } } })
      // Render the new password setup page
      res.render('new-password', {
        formCSS: true,
        formValidateJS: true,
        userId: user.id,
        passwordToken: token
      })
    } catch (err) {
      res.redirect('/users/reset')
      console.log(err)
    }
  },
  postNewPassword: async (req, res) => {
    const { password, userId, passwordToken } = req.body
    // Get all validation error messages in an object
    const errors = validationResult(req)
    // If any error messages are prompted, show a warning message
    if (!errors.isEmpty()) {
      return res.status(422).render('new-password', {
        formCSS: true,
        formValidateJS: true,
        userId: user.id,
        passwordToken: token
      })
    }

    // Form passed validation
    try {
      // Find user 
      const user = await User.findOne({ resetToken: passwordToken, resetTokenExpiration: { [Op.gt]: Date.now() }, id: userId })
      // Hash new password
      const salt = await bcrypt.genSalt(10)
      const hash = await bcrypt.hash(password, salt)
      // Update password and clear token-related data
      user.password = hash
      user.resetToken = null
      user.resetTokenExpiration = null
      await user.save()
      // Redirect back to the login page
      res.redirect('/users/login')

    } catch (err) {
      res.redirect('/users/reset')
      console.log(err)
    }
  }
}
