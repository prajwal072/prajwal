module.exports = (req, res, next) => {
  // If not authenticated, redirect to the login page
  if (!req.isAuthenticated()) {
    req.flash('reminder', 'Not logged in yet, please log in first');
    return res.redirect('/users/login');
  }
  next();
};
