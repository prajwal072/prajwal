// Include modules 
const passport = require('passport')
const LocalStrategy = require('passport-local').Strategy
const FacebookStrategy = require('passport-facebook').Strategy
const bcrypt = require('bcryptjs')

// Include models
const db = require('../models')
const User = db.User

module.exports = passport => {
  // Configure strategy using use() function
  passport.use(new LocalStrategy({
    // Ask LocalStrategy to find username in the parameter named email
    usernameField: 'email',
    // Also pass req to verify callback
    passReqToCallback: true
  },
    // Set up a verify callback to accept credentials
    function (req, username, password, done) {
      User.findOne({ where: { email: username } })
        .then(user => {
          // No such user
          if (!user) { return done(null, false, req.flash('error', 'Incorrect email input')) }
          // User exists, but with an incorrect password
          bcrypt.compare(password, user.password, (err, isMatch) => {
            // Password correct
            if (isMatch) { return done(null, user) }
            // Password incorrect
            return done(null, false, req.flash('error', 'Incorrect password input'))
          })
        })
        .catch(err => {
          return done(err)
        })
    }
  ))

  // Configure Facebook authentication
  passport.use(new FacebookStrategy({
    clientID: process.env.FACEBOOK_ID,
    clientSecret: process.env.FACEBOOK_SECRET,
    callbackURL: process.env.FACEBOOK_CALLBACK,
    profileFields: ['email', 'displayName']
  },
    function (accessToken, refreshToken, profile, done) {
      User.findOne({ where: { email: profile._json.email } })
        .then(user => {
          if (!user) {
            const randomPassword = Math.random().toString(36).slice(-8)
            bcrypt.genSalt(10, (err, salt) => {
              bcrypt.hash(randomPassword, salt, (err, hash) => {
                const newUser = new User({
                  name: profile._json.name,
                  email: profile._json.email,
                  password: hash
                })
                newUser.save()
                  .then(user => done(null, user))
                  .catch(err => console.log(err))
              })
            })
          } else {
            // If user exists
            return done(null, user)
          }
        })
    }
  ))

  // Serialize user instance to the session
  passport.serializeUser((user, done) => {
    done(null, user.id)
  })

  // Deserialize user instance from the session
  passport.deserializeUser((id, done) => {
    // ID from the session is used to find the user and store it in req.user
    User.findByPk(id)
      .then(user => done(null, user))
      .catch(err => done(err))
  })
}
