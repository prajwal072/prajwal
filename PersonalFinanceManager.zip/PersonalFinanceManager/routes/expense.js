const express = require('express')
const router = express.Router()

// Include Controllers
const expenseController = require('../controllers/expense')

// Include check package from express-validator
const { body } = require('express-validator')
// Include authentication middleware
const isAuthenticated = require('../config/auth')

// Create new expense page
router.get('/new', isAuthenticated, expenseController.getNewExpense)

// Create new expense submit
router.post('/new', isAuthenticated, [
  // Name is required
  body('name')
    .trim()
    .isLength({ min: 1, max: 8 })
    .withMessage('Name is required and must be up to 8 characters!'),
  // Date is required and should be in date format
  body('date')
    .isISO8601()
    .isAfter('2000-01-01')
    .isBefore('2030-01-01')
    .withMessage('Date is missing or not within the valid range'),
  body('category')
    .custom(value => {
      if (!['Home & Property', 'Transportation', 'Leisure & Entertainment', 'Food & Dining', 'Others'].includes(value)) {
        throw new Error('Please select a category')
      }
      return true
    }),
  // Amount is required and should be a positive integer
  body('amount')
    .trim()
    .isInt({ min: 1, max: 99999 })
    .withMessage('Amount is required and must be less than 100,000!')
], expenseController.postNewExpense)

// Edit expense page
router.get('/edit/:id', isAuthenticated, expenseController.getEditExpense)

// Edit expense submit
router.put('/edit/:id', isAuthenticated, [
  // Name is required
  body('name')
    .trim()
    .isLength({ min: 1, max: 8 })
    .withMessage('Name is required and must be up to 8 characters!'),
  // Date is required and should be in date format
  body('date')
    .isISO8601()
    .isAfter('2000-01-01')
    .isBefore('2030-01-01')
    .withMessage('Date is missing or not within the valid range'),
  body('category')
    .custom(value => {
      if (!['Home & Property', 'Transportation', 'Leisure & Entertainment', 'Food & Dining', 'Others'].includes(value)) {
        throw new Error('Please select a category')
      }
      return true
    }),
  // Amount is required and should be a positive integer
  body('amount')
    .trim()
    .isInt({ min: 1, max: 99999 })
    .withMessage('Amount is required and must be less than 100,000!')
], expenseController.postEditExpense)

// Delete expense 
router.delete('/delete/:id', isAuthenticated, expenseController.deleteExpense)

module.exports = router
