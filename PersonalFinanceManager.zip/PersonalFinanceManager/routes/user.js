const express = require('express')
const router = express.Router()
const { body } = require('express-validator')
const passport = require('passport')

// Include controller
const userController = require('../controllers/user')

// Signup page
router.get('/register', userController.getRegister)

// Signup submit page
router.post('/register', [
  // Name is required
  body('name')
    .trim()
    .isLength({ min: 1 })
    .withMessage('Name is required and cannot be just spaces'),
  // Email is required and must follow email format
  body('email')
    .trim()
    .isEmail()
    .withMessage('Email is required and must be in the format: xx@xx.xx'),
  // Password is required
  body('password')
    .custom((value) => {
      const regex = /^\S{8,12}$/;
      if (!value.match(regex)) {
        throw new Error('Password must be 8-12 characters long and cannot contain spaces');
      }
      return true;
    }),
  // Re-entered password is required and should match the first input
  body('rePassword')
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('The two entered passwords do not match');
      }
      return true;
    })
], userController.postRegister)

// Login page
router.get('/login', userController.getLogin)

// Login submit page
router.post('/login', passport.authenticate('local', {
  successRedirect: '/',
  failureRedirect: '/users/login',
  failureFlash: true
}))

// Logout page
router.get('/logout', userController.getLogout)

// Reset password page: send email
router.get('/reset', userController.getReset)

// Reset password submit: send email
router.post('/reset', userController.postRest)

// Reset password page: from email link
router.get('/reset/:token', userController.getNewPassword)

// Reset password submit: from email link
router.post('/new-password', [
  // Password is required
  body('password')
    .custom((value) => {
      const regex = /^\S{8,12}$/;
      if (!value.match(regex)) {
        throw new Error('Password must be 8-12 characters long and cannot contain spaces');
      }
      return true;
    }),
  // Re-entered password is required and should match the first input
  body('rePassword')
    .trim()
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('The two entered passwords do not match');
      }
      return true;
    })
], userController.postNewPassword)

module.exports = router
